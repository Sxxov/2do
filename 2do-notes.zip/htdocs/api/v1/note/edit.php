<?php

namespace api\v1\auth;

use api\v1\lib\common\HttpCodes;
use api\v1\lib\common\ResErr;
use api\v1\lib\common\ResErrCodes;
use api\v1\lib\common\ResOk;
use api\v1\lib\db\Db;
use api\v1\lib\db\DbInfo;
use api\v1\lib\note\Note as NoteNote;
use api\v1\lib\note\Note;
use api\v1\lib\user\User;
use DateTime;
use mysqli_sql_exception;

$db = Db::connect(DbInfo::getApp());

$body = file_get_contents('php://input');
$in = json_decode($body);

if (!isset($in->username) || !isset($in->password) || !isset($in->email)) {
	return ResErr::send(ResErrCodes::INCOMPLETE, http: HttpCodes::BAD_REQUEST);
}

session_start();
$sessionId = session_id();

if (!$sessionId) {
	return ResErr::send(
		ResErrCodes::UNAUTHORISED,
		http: HttpCodes::UNAUTHORISED,
	);
}

$db = Db::connect(DbInfo::getApp());

try {
	$row = $db->query(
		<<<SQL
		SELECT user_id FROM sessions WHERE session_id = "{$db->real_escape_string(
			$sessionId,
		)}";
		SQL
		,
	);

	if ($row->num_rows <= 0) {
		return ResErr::send(
			ResErrCodes::UNAUTHORISED,
			http: HttpCodes::UNAUTHORISED,
		);
	}

	$userId = $row->fetch_assoc()['user_id'];
} catch (mysqli_sql_exception $err) {
	return ResErr::send(
		ResErrCodes::UNKNOWN,
		http: HttpCodes::INTERNAL_SERVER_ERROR,
		message: 'Failed to get user id from session',
		detail: $err,
	);
}

$updatedTitle = $in->title;
$updatedDescription = $in->description;
$datetime = new DateTime();
$dateModified = $datetime->format('Y-m-d H:i:s');

try {
    $query = <<<SQL
        UPDATE notes SET title = "{$db->real_escape_string($updatedTitle)}",
                        description = "{$db->real_escape_string($updatedDescription)}",
                        dateModified = "{$db->real_escape_string($dateModified)}"
        WHERE todo_id = "{$db->real_escape_string($id)}";
    SQL;

    $db->query($query);

    // Check if the update was successful
    if ($db->affected_rows > 0) {
        $note = new Note(
            id: $row['user_id'],
            title: $row['title'],
            owner: $row['owner'],
            description: $row['description'],
            dateCreated: $row['dateCreated'],
            dateModified: $row['dateModified']
        );
        return ResOk::send('Note updated successfully');
    } else {
        return ResErr::send(
            ResErrCodes::NOTE_UPDATE_ERROR,
            http: HttpCodes::BAD_REQUEST,
            message: 'Failed to update note'
        );
    }
} catch (mysqli_sql_exception $err) {
    return ResErr::send(
        ResErrCodes::UNKNOWN,
        http: HttpCodes::INTERNAL_SERVER_ERROR,
        message: 'Failed to update note',
        detail: $err
    );
}

return ResOk::send($note);
